// Container
const UI = require("sketch/ui");
var document = require('sketch/dom').getSelectedDocument()

// Large
var containerLg = function(context) {
  var selectedLayers = document.selectedLayers
  var selectedCount = selectedLayers.length

  if (selectedCount === 0) {
    UI.message("No artboards are selected.");
  } else {
    selectedLayers.forEach(function (layer, i) {
      if (layer.type == "Artboard") {
        const isArtboard = item => item.class() == 'MSArtboardGroup';
        const isSymbolMaster = item => item.class() == 'MSSymbolMaster';
        const isArtboardOrIsSymbolMaster = item => isArtboard || isSymbolMaster;

        const setLayoutSettings = artboard => {  }

        context.selection.slice()
        .filter(isArtboardOrIsSymbolMaster)
        .map(artboard => {

          const layout = MSLayoutGrid.alloc().init();

          layout.setTotalWidth(1140);
          layout.setNumberOfColumns(12);
          layout.setHorizontalOffset(150);
          layout.setGutterWidth(20);

          layout.setIsEnabled(true);
          artboard.setLayout(layout);
        });

        UI.message("Layout Applied!");
      } else {
        UI.message(layer.name + " layer is not an artboard.");
      }
    })
  }
};

// Medium
var containerMd = function(context) {
  var selectedLayers = document.selectedLayers
  var selectedCount = selectedLayers.length

  if (selectedCount === 0) {
    UI.message("No artboards are selected.");
  } else {
    selectedLayers.forEach(function (layer, i) {
      if (layer.type == "Artboard") {
        const isArtboard = item => item.class() == 'MSArtboardGroup';
        const isSymbolMaster = item => item.class() == 'MSSymbolMaster';
        const isArtboardOrIsSymbolMaster = item => isArtboard || isSymbolMaster;

        const setLayoutSettings = artboard => {  }

        context.selection.slice()
        .filter(isArtboardOrIsSymbolMaster)
        .map(artboard => {

          const layout = MSLayoutGrid.alloc().init();

          layout.setTotalWidth(860);
          layout.setNumberOfColumns(12);
          layout.setHorizontalOffset(170);
          layout.setGutterWidth(20);

          layout.setIsEnabled(true);
          artboard.setLayout(layout);
        });

        UI.message("Layout Applied!");
      } else {
        UI.message(layer.name + " layer is not an artboard.");
      }
    })
  }
};

// Small
var containerSm = function(context) {
  var selectedLayers = document.selectedLayers
  var selectedCount = selectedLayers.length

  if (selectedCount === 0) {
    UI.message("No artboards are selected.");
  } else {
    selectedLayers.forEach(function (layer, i) {
      if (layer.type == "Artboard") {
        const isArtboard = item => item.class() == 'MSArtboardGroup';
        const isSymbolMaster = item => item.class() == 'MSSymbolMaster';
        const isArtboardOrIsSymbolMaster = item => isArtboard || isSymbolMaster;

        const setLayoutSettings = artboard => {  }

        context.selection.slice()
        .filter(isArtboardOrIsSymbolMaster)
        .map(artboard => {

          const layout = MSLayoutGrid.alloc().init();

          layout.setTotalWidth(560);
          layout.setNumberOfColumns(12);
          layout.setHorizontalOffset(170);
          layout.setGutterWidth(10);

          layout.setIsEnabled(true);
          artboard.setLayout(layout);
        });

        UI.message("Layout Applied!");
      } else {
        UI.message(layer.name + " layer is not an artboard.");
      }
    })
  }
};

// // Extra Small
// var containerXs = function(context) {
//   var selectedLayers = document.selectedLayers
//   var selectedCount = selectedLayers.length
//
//   if (selectedCount === 0) {
//     UI.message("No artboards are selected.");
//   } else {
//     selectedLayers.forEach(function (layer, i) {
//       if (layer.type == "Artboard") {
//         const isArtboard = item => item.class() == 'MSArtboardGroup';
//         const isSymbolMaster = item => item.class() == 'MSSymbolMaster';
//         const isArtboardOrIsSymbolMaster = item => isArtboard || isSymbolMaster;
//
//         const setLayoutSettings = artboard => {  }
//
//         context.selection.slice()
//         .filter(isArtboardOrIsSymbolMaster)
//         .map(artboard => {
//
//           const layout = MSLayoutGrid.alloc().init();
//
//           layout.setTotalWidth(560);
//           layout.setNumberOfColumns(12);
//           layout.setHorizontalOffset(20);
//           layout.setGutterWidth(10);
//
//           layout.setIsEnabled(true);
//           artboard.setLayout(layout);
//         });
//
//         UI.message("Layout Applied!");
//       } else {
//         UI.message(layer.name + " layer is not an artboard.");
//       }
//     })
//   }
// };
//
// // iPhone
// var containeriPhone = function(context) {
//   var selectedLayers = document.selectedLayers
//   var selectedCount = selectedLayers.length
//
//   if (selectedCount === 0) {
//     UI.message("No artboards are selected.");
//   } else {
//     selectedLayers.forEach(function (layer, i) {
//       if (layer.type == "Artboard") {
//         const isArtboard = item => item.class() == 'MSArtboardGroup';
//         const isSymbolMaster = item => item.class() == 'MSSymbolMaster';
//         const isArtboardOrIsSymbolMaster = item => isArtboard || isSymbolMaster;
//
//         const setLayoutSettings = artboard => {  }
//
//         context.selection.slice()
//         .filter(isArtboardOrIsSymbolMaster)
//         .map(artboard => {
//
//           const layout = MSLayoutGrid.alloc().init();
//
//           layout.setTotalWidth(335);
//           layout.setNumberOfColumns(12);
//           layout.setHorizontalOffset(20);
//           layout.setGutterWidth(10);
//
//           layout.setIsEnabled(true);
//           artboard.setLayout(layout);
//         });
//
//         UI.message("Layout Applied!");
//       } else {
//         UI.message(layer.name + " layer is not an artboard.");
//       }
//     })
//   }
// };
