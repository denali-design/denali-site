# Theme Your HTML Using Denali

### Prerequisites
Install the list of prerequisites below. You'll also need a basic knowledge of SCSS, CSS, and HTML.
- [Node.js](https://nodejs.org/)
- [npm](https://www.npmjs.com/)
- [SCSS](https://sass-lang.com/)

### Guide
1. Install Denali's SCSS `npm i denali-css`
2. Compile SCSS `sass --watch theme.scss`
3. Update variables in the theme.scss
4. Reload the HTML and see your theme in action

### Helpful Links
- [Denali Homepage](https://denali.design/)
- [Denali GitHub](https://github.com/denali-design)
- You can find component variables at the bottom of each component page. [Buttons Variables](https://denali.design/docs/2.1.0/components/buttons#variables)
- [Global Variables](https://denali.design/docs/2.1.0/guides/global-variables)